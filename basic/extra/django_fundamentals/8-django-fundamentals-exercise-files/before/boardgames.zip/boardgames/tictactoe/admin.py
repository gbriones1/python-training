from django.contrib import admin

from .models import Game, Move


admin.site.register(Game)
admin.site.register(Move)

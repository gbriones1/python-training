
class SeatFinder:
    def __init__(self, available_seats):
        self.available_seats = available_seats
        
    def find_seats(self, count, wheelchair_count=0):
        # left as an exercise
        pass